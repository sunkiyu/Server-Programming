#pragma once

extern thread_local uint32 LThreadId;